"""小清新 UI 主题 v2：更鲜明的果冻质感。

设计语言：
- 莫兰迪色系加强饱和度：薄荷青 #3aa88f / 蜜桃粉 #f79e7d / 雾霭紫 #9d9ff0
- 毛玻璃：blur(22px) saturate(1.5) + 双层描边 + 内侧高光
- 果冻弹性：spring 缓动（过冲回弹）+ 节点弹跳 + 按钮果冻压感
- 装饰组件：自动轮播小卡片条（marquee，hover 暂停，只占一条缝隙高度）
- 复现流程：8 节点步进器（果冻激活、进度线弹性填充）
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Sequence, Tuple

APP_CSS = """
<style>
html, body, .stApp, .stApp * :not(pre):not(code):not(.telemetry-log) {
    font-family: "Segoe UI", "Microsoft YaHei", "Microsoft YaHei UI", "PingFang SC", "Noto Sans SC", sans-serif !important;
}
:root {
    --bg-0: #eef8f3;
    --bg-1: #e9f2fb;
    --bg-2: #f6eff7;
    --panel: rgba(255, 255, 255, 0.72);
    --panel-strong: rgba(255, 255, 255, 0.92);
    --line: rgba(14, 106, 79, 0.35);
    --teal: #3aa88f;
    --mint: #7fd6bd;
    --mint-soft: #dcf3ea;
    --peach: #f79e7d;
    --peach-soft: #ffe7db;
    --lavender: #9d9ff0;
    --lavender-soft: #e9e9fc;
    --amber: #eaa73b;
    --red: #e5697d;
    --text: #1b3138;
    --muted: #5e7d87;
    --spring: cubic-bezier(0.34, 1.56, 0.64, 1);
    --spring-soft: cubic-bezier(0.22, 0.9, 0.35, 1.4);
    --shadow: 0 16px 42px rgba(58, 168, 143, 0.16);
    --shadow-hover: 0 26px 56px rgba(58, 168, 143, 0.26);
}
html, body {
    height: 100%;
}
body {
    background:
        radial-gradient(circle at 4% 2%, rgba(42, 178, 137, 0.62), transparent 38%),
        radial-gradient(circle at 96% 4%, rgba(233, 96, 60, 0.48), transparent 34%),
        radial-gradient(circle at 84% 90%, rgba(100, 105, 230, 0.50), transparent 38%),
        radial-gradient(circle at 6% 86%, rgba(42, 178, 137, 0.45), transparent 34%),
        linear-gradient(155deg, #b9e3cf, #bcd6f2 48%, #ecd0e6);
    background-attachment: fixed;
}
.stApp {
    background: transparent;
    color: var(--text);
}
.stApp > div, .stSidebar > div {
    background: transparent;
}
.stSidebar > div {
    background: linear-gradient(180deg, rgba(255,255,255,0.9), rgba(232, 246, 238, 0.88));
    border-right: 1.5px solid rgba(94, 202, 173, 0.4);
    box-shadow: inset -1px 0 0 rgba(255,255,255,0.9);
    backdrop-filter: blur(26px) saturate(1.5);
    -webkit-backdrop-filter: blur(26px) saturate(1.5);
}
.stSidebar .stMarkdown, .stSidebar p, .stSidebar span {
    color: var(--muted);
}
h1, h2, h3, h4 {
    color: #2f6b5c;
    letter-spacing: 0.04em;
    font-weight: 800;
}
h1 {
    background: linear-gradient(120deg, #0e6a4f, #e03e12 52%, #5a5fd0);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    display: inline-block;
    filter: drop-shadow(0 2px 8px rgba(58, 168, 143, 0.25));
}
.block-container {
    padding-top: 0.8rem;
    padding-bottom: 2.5rem;
    max-width: 1500px;
}
/* —— 输入控件 —— */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stNumberInput > div > div > input {
    background: rgba(255, 255, 255, 0.9);
    border: 1px solid rgba(58, 168, 143, 0.28);
    border-radius: 12px;
    color: var(--text);
    transition: all 0.3s var(--spring-soft);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.8);
}
.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus,
.stNumberInput > div > div > input:focus {
    border-color: var(--teal);
    box-shadow: 0 0 0 4px rgba(58, 168, 143, 0.18), inset 0 1px 0 #fff;
}
.stSelectbox [data-baseweb="select"] > div {
    background: rgba(255, 255, 255, 0.9);
    border: 1px solid rgba(58, 168, 143, 0.28);
    border-radius: 12px;
}
.stCheckbox label p, .stCaption, label p {
    color: var(--muted);
}
/* —— 按钮：果冻弹跳 —— */
.stButton > button,
div[data-testid="stFormSubmitButton"] button {
    background: linear-gradient(160deg, rgba(255,255,255,0.96), rgba(240,250,246,0.9));
    color: #14503e;
    border: 1.5px solid rgba(14, 106, 79, 0.6);
    border-radius: 14px;
    font-weight: 700;
    letter-spacing: 0.04em;
    transition: all 0.3s var(--spring);
    min-height: 44px;
    box-shadow: 0 6px 18px rgba(58, 168, 143, 0.14), inset 0 1px 0 rgba(255,255,255,0.9);
}
.stButton > button:hover,
div[data-testid="stFormSubmitButton"] button:hover {
    background: linear-gradient(160deg, #e2f5ec, #ffffff);
    border-color: var(--teal);
    color: #0d4433;
    transform: translateY(-3px) scale(1.02);
    box-shadow: 0 14px 30px rgba(58, 168, 143, 0.30), inset 0 1px 0 #fff;
}
.stButton > button:active,
div[data-testid="stFormSubmitButton"] button:active {
    transform: translateY(0) scale(0.95);
    transition: transform 0.12s ease;
}
div[data-testid="stFormSubmitButton"] button {
    background: linear-gradient(135deg, #1c8a6a, #4fc8a0 65%, #8fe0c0);
    color: #ffffff;
    border: none;
    box-shadow: 0 10px 26px rgba(58, 168, 143, 0.4), inset 0 1.5px 0 rgba(255,255,255,0.6);
    text-shadow: 0 1px 2px rgba(31, 92, 76, 0.3);
}
div[data-testid="stFormSubmitButton"] button:hover {
    background: linear-gradient(135deg, #0e6a4f, #38b58d 65%, #7fd6bd);
    color: #ffffff;
    transform: translateY(-3px) scale(1.02);
    box-shadow: 0 16px 34px rgba(58, 168, 143, 0.5), inset 0 1.5px 0 rgba(255,255,255,0.6);
}
/* —— 代码块 —— */
[data-testid="stCodeBlock"], code, pre {
    background: rgba(244, 250, 247, 0.9) !important;
    border: 1px solid rgba(58, 168, 143, 0.2);
    border-radius: 12px;
    color: #35635a;
}
[data-testid="stExpander"] details {
    background: rgba(255, 255, 255, 0.78);
    border: 1px solid rgba(58, 168, 143, 0.24);
    border-radius: 14px;
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    transition: all 0.3s var(--spring-soft);
}
[data-testid="stExpander"] details:hover {
    box-shadow: var(--shadow);
    border-color: rgba(58, 168, 143, 0.5);
}
/* —— 顶部标题区 —— */
.fresh-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    flex-wrap: wrap;
    padding: 0.6rem 0.4rem 0.2rem;
    animation: jellyPop 0.6s var(--spring) both;
}
.fresh-kicker {
    color: var(--teal);
    font-size: 0.72rem;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    margin-bottom: 0.25rem;
    font-weight: 700;
}
.fresh-sub {
    color: var(--muted);
    font-size: 0.95rem;
    margin-top: 0.3rem;
}
.weather-chip {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: linear-gradient(135deg, rgba(255,255,255,0.96), rgba(214, 243, 233, 0.9));
    border: 1.5px solid rgba(94, 202, 173, 0.55);
    border-radius: 999px;
    padding: 0.55rem 1.1rem;
    color: var(--text);
    font-size: 0.85rem;
    font-weight: 600;
    box-shadow: 0 10px 28px rgba(58, 168, 143, 0.24), inset 0 1px 0 rgba(255,255,255,0.9);
    backdrop-filter: blur(20px) saturate(1.5);
    -webkit-backdrop-filter: blur(20px) saturate(1.5);
    transition: transform 0.3s var(--spring), box-shadow 0.3s ease;
    animation: jellyPop 0.7s var(--spring) both;
}
.weather-chip:hover {
    transform: translateY(-3px) scale(1.04);
    box-shadow: 0 16px 36px rgba(58, 168, 143, 0.34), inset 0 1px 0 #fff;
}
.weather-chip .emoji {
    display: none;
    font-size: 1.2rem;
    background: linear-gradient(135deg, rgba(94,202,173,0.25), rgba(247,143,108,0.22));
    border-radius: 50%;
    width: 30px;
    height: 30px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    animation: chipFloat 3s ease-in-out infinite;
}
@keyframes chipFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-2.5px); }
}
/* —— 通用面板：明显毛玻璃 —— */
.panel {
    background: linear-gradient(160deg, rgba(255,255,255,0.97), rgba(240, 252, 246, 0.92));
    border: 1.5px solid rgba(14, 106, 79, 0.30);
    border-radius: 20px;
    padding: 1rem;
    box-shadow: 0 18px 44px rgba(58, 168, 143, 0.22), inset 0 1.5px 0 rgba(255,255,255,0.95);
    backdrop-filter: blur(22px) saturate(1.5);
    -webkit-backdrop-filter: blur(22px) saturate(1.5);
    transition: transform 0.35s var(--spring), box-shadow 0.35s ease, border-color 0.35s ease;
    animation: jellyPop 0.5s var(--spring) both;
}
.panel:hover {
    transform: translateY(-5px) scale(1.012);
    border-color: rgba(127, 214, 189, 0.9);
    box-shadow: 0 28px 60px rgba(58, 168, 143, 0.28), 0 0 0 3px rgba(127, 214, 189, 0.22), inset 0 1.5px 0 #fff;
}
.panel-title {
    color: #2b8a72;
    letter-spacing: 0.1em;
    font-size: 0.74rem;
    font-weight: 800;
    margin-bottom: 0.75rem;
    border-left: 4px solid;
    border-image: linear-gradient(180deg, var(--teal), var(--peach)) 1;
    padding-left: 0.5rem;
}
.floating-card {
    background: linear-gradient(160deg, rgba(255,255,255,0.97), rgba(255, 243, 235, 0.9));
    border: 1.5px solid rgba(224, 62, 18, 0.25);
    border-radius: 18px;
    padding: 0.8rem 0.9rem;
    backdrop-filter: blur(20px) saturate(1.5);
    -webkit-backdrop-filter: blur(20px) saturate(1.5);
    box-shadow: 0 14px 36px rgba(58, 168, 143, 0.15), inset 0 1px 0 rgba(255,255,255,0.95);
    transition: transform 0.35s var(--spring), box-shadow 0.35s ease, border-color 0.35s ease;
    animation: jellyPop 0.5s var(--spring) both;
}
.floating-card:hover {
    transform: translateY(-5px) scale(1.02);
    border-color: rgba(247, 158, 125, 0.75);
    box-shadow: 0 24px 52px rgba(58, 168, 143, 0.26), inset 0 1px 0 #fff;
}
.floating-card.small {
    opacity: 0.98;
}
.mini-title {
    color: var(--muted);
    font-size: 0.7rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    margin-bottom: 0.5rem;
}
.status-dot {
    display: inline-block;
    width: 9px;
    height: 9px;
    border-radius: 50%;
    margin-right: 0.45rem;
    vertical-align: middle;
    box-shadow: 0 0 8px rgba(26, 74, 62, 0.25);
}
/* —— 复现流程步进器（果冻节点） —— */
.fx-stepper {
    display: flex;
    align-items: flex-start;
    padding: 0.55rem 0.2rem 0.2rem;
}
.fx-step {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.32rem;
    position: relative;
    min-width: 0;
}
.fx-step .node {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    font-size: 15px;
    background: linear-gradient(160deg, #ffffff, #e3f4ec);
    border: 2px solid rgba(58, 168, 143, 0.45);
    color: #2b8a72;
    box-shadow: 0 6px 14px rgba(58, 168, 143, 0.14), inset 0 1px 0 #fff;
    transition: transform 0.4s var(--spring), box-shadow 0.4s ease, background 0.4s ease, border-color 0.4s ease;
    z-index: 1;
}
.fx-step .bar {
    position: absolute;
    top: 17px;
    left: 50%;
    width: 100%;
    height: 3.5px;
    background: rgba(58, 168, 143, 0.16);
    border-radius: 999px;
    overflow: hidden;
    z-index: 0;
}
.fx-step .bar::after {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg, var(--teal), var(--mint));
    border-radius: 999px;
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.7s var(--spring);
}
.fx-step.done .node {
    background: linear-gradient(135deg, var(--teal), var(--mint));
    border-color: transparent;
    color: #fff;
    box-shadow: 0 8px 20px rgba(58, 168, 143, 0.4), inset 0 1px 0 rgba(255,255,255,0.5);
}
.fx-step.done .bar::after {
    transform: scaleX(1);
}
.fx-step.error .node {
    background: linear-gradient(135deg, #e5697d, #f3a0ae);
    border-color: rgba(255, 255, 255, 0.95);
    color: #fff;
    animation: nodeBounce 1.15s var(--spring) infinite;
    box-shadow: 0 0 0 7px rgba(229, 105, 125, 0.2), 0 12px 26px rgba(229, 105, 125, 0.45);
}
.fx-step.error .cap {
    color: #c74d63;
    font-weight: 800;
}
.fx-step.active .node {
    background: linear-gradient(135deg, var(--peach), #fec79e);
    border-color: rgba(255, 255, 255, 0.95);
    color: #fff;
    animation: nodeBounce 1.15s var(--spring) infinite;
    box-shadow: 0 0 0 7px rgba(247, 158, 125, 0.20), 0 12px 26px rgba(247, 158, 125, 0.45);
}
.fx-step .cap {
    font-size: 0.62rem;
    color: var(--muted);
    letter-spacing: 0.04em;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
}
.fx-step.done .cap {
    color: var(--teal);
    font-weight: 700;
}
.fx-step.active .cap {
    color: #d87a52;
    font-weight: 800;
}
@keyframes nodeBounce {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.16); }
}
.fx-stepper-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.6rem;
    margin-top: 0.55rem;
    flex-wrap: wrap;
}
.fx-stepper-meta .meta-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.3rem 0.7rem;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.85);
    border: 1px solid rgba(58, 168, 143, 0.28);
    color: var(--text);
    font-size: 0.72rem;
    font-weight: 600;
    box-shadow: 0 4px 12px rgba(58, 168, 143, 0.12);
}
.fx-stepper-meta .meta-pill b {
    color: var(--teal);
}
/* —— 装饰轮播（自动滚动小卡片，hover 暂停） —— */
.fx-carousel {
    position: relative;
    overflow: hidden;
    padding: 0.55rem 0 0.25rem;
    border-radius: 18px;
    -webkit-mask-image: linear-gradient(90deg, transparent, #000 5%, #000 95%, transparent);
    mask-image: linear-gradient(90deg, transparent, #000 5%, #000 95%, transparent);
    animation: jellyPop 0.6s var(--spring) both;
}
.fx-track {
    display: flex;
    gap: 0.65rem;
    width: max-content;
    animation: fxScroll 28s linear infinite;
}
.fx-carousel:hover .fx-track,
.fx-carousel:focus-within .fx-track {
    animation-play-state: paused;
}
@keyframes fxScroll {
    to { transform: translateX(-50%); }
}
.fx-card {
    background: linear-gradient(160deg, rgba(255,255,255,0.95), rgba(255,255,255,0.62));
    border: 1.5px solid rgba(94, 202, 173, 0.4);
    border-radius: 16px;
    padding: 0.5rem 0.9rem;
    display: flex;
    align-items: center;
    gap: 0.55rem;
    box-shadow: 0 10px 24px rgba(58, 168, 143, 0.16), inset 0 1px 0 #fff;
    backdrop-filter: blur(18px) saturate(1.45);
    -webkit-backdrop-filter: blur(18px) saturate(1.45);
    white-space: nowrap;
    transition: transform 0.35s var(--spring), box-shadow 0.35s ease;
}
.fx-card:nth-child(3n+2) {
    background: linear-gradient(160deg, rgba(255,255,255,0.95), rgba(255, 231, 219, 0.72));
    border-color: rgba(247, 143, 108, 0.45);
}
.fx-card:nth-child(3n+3) {
    background: linear-gradient(160deg, rgba(255,255,255,0.95), rgba(233, 233, 252, 0.75));
    border-color: rgba(146, 149, 240, 0.42);
}
.fx-card:hover {
    transform: translateY(-4px) scale(1.05);
    box-shadow: 0 16px 34px rgba(58, 168, 143, 0.28), inset 0 1px 0 #fff;
}
.fx-card .dot-mark {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--teal), var(--mint));
    flex-shrink: 0;
}
.fx-card .t {
    color: #2b6e5c;
    font-weight: 800;
    font-size: 0.8rem;
}
.fx-card .s {
    color: var(--muted);
    font-size: 0.7rem;
    margin-left: 0.15rem;
}
/* —— 遥测面板 —— */
.telemetry-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 0.7rem;
    margin-top: 0.6rem;
}
.telemetry-metric {
    background: linear-gradient(160deg, rgba(255,255,255,0.9), rgba(255,255,255,0.55));
    border: 1px solid rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 0.7rem 0.8rem;
    display: flex;
    flex-direction: column;
    gap: 0.2rem;
    backdrop-filter: blur(16px) saturate(1.4);
    -webkit-backdrop-filter: blur(16px) saturate(1.4);
    transition: transform 0.35s var(--spring), box-shadow 0.35s ease;
}
.telemetry-metric:hover {
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 14px 30px rgba(58, 168, 143, 0.22);
}
.telemetry-label {
    color: var(--muted);
    font-size: 0.68rem;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}
.telemetry-metric strong {
    color: #2b6e5c;
    font-size: 0.92rem;
    word-break: break-all;
}
.telemetry-subpanel {
    margin-top: 0.9rem;
    background: rgba(255, 255, 255, 0.55);
    border: 1px solid rgba(255, 255, 255, 0.85);
    border-radius: 15px;
    padding: 0.8rem 0.85rem;
    backdrop-filter: blur(16px) saturate(1.4);
    -webkit-backdrop-filter: blur(16px) saturate(1.4);
}
.directory-list {
    margin: 0.4rem 0 0;
    padding-left: 1rem;
    color: var(--text);
    line-height: 1.8;
}
.directory-list li {
    display: flex;
    justify-content: space-between;
    gap: 0.6rem;
    align-items: center;
}
.directory-list code {
    color: #2f9d84;
    font-size: 0.72rem;
    background: var(--mint-soft);
    border-radius: 8px;
    padding: 0.1rem 0.35rem;
    white-space: nowrap;
}
.telemetry-log {
    margin: 0.5rem 0 0;
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 0.75rem;
    line-height: 1.6;
    color: var(--text);
    background: rgba(244, 250, 247, 0.9);
    border: 1px solid rgba(58, 168, 143, 0.18);
    border-radius: 12px;
    padding: 0.7rem;
    max-height: 220px;
    overflow: auto;
}
.telemetry-log::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}
.telemetry-log::-webkit-scrollbar-thumb {
    background: rgba(58, 168, 143, 0.4);
    border-radius: 999px;
}
.telemetry-log::-webkit-scrollbar-track {
    background: rgba(58, 168, 143, 0.06);
}
/* —— 果冻入场 —— */
@keyframes jellyPop {
    0% { opacity: 0; transform: scale(0.9) translateY(10px); }
    55% { opacity: 1; transform: scale(1.04) translateY(-2px); }
    78% { transform: scale(0.985); }
    100% { opacity: 1; transform: scale(1) translateY(0); }
}
section.main > div[data-testid="stVerticalBlock"] > div > div {
    animation: jellyPop 0.5s var(--spring) both;
}
/* —— 响应式 —— */
@media (max-width: 1000px) {
    .telemetry-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .fx-step .cap { font-size: 0.56rem; }
    .fx-step .node { width: 30px; height: 30px; font-size: 13px; }
    .fx-step .bar { top: 14px; }
}
@media (max-width: 620px) {
    .telemetry-grid { grid-template-columns: 1fr; }
    .fresh-header { flex-direction: column; align-items: flex-start; }
    .fx-step .cap { display: none; }
    .fx-stepper-meta { flex-direction: column; align-items: flex-start; }
}
</style>
"""

# 复现流程步骤：(id, 标题, 图标)
PIPELINE_STEPS: List[Tuple[str, str, str]] = [
    ("prepare", "准备", "准"),
    ("clone", "拉取", "拉"),
    ("env", "环境诊断", "环"),
    ("install", "装依赖", "装"),
    ("dependencies", "补装", "补"),
    ("dataset", "数据集", "数"),
    ("verify", "验证", "验"),
    ("collect", "收集", "收"),
]

# 装饰轮播小卡片：(emoji, 标题, 副标题)
CAROUSEL_CARDS: List[Tuple[str, str, str]] = [
    ("云端执行", "conda / venv / docker 自动适配"),
    ("日志回流", "实时滚动 + 一键根因诊断"),
    ("数据安全", "任务产物只存本机"),
    ("仓库智选", "全网匹配最优复现仓库"),
    ("环境自检", "Python / 依赖 / CUDA 诊断"),
]


def build_carousel_html() -> str:
    """装饰轮播条：内容复制两遍实现无缝循环；hover 暂停。"""
    cards = "".join(
        f"<div class='fx-card'><span class='dot-mark'></span>"
        f"<span class='t'>{title}</span><span class='s'>{sub}</span></div>"
        for title, sub in CAROUSEL_CARDS
    )
    return f"""
    <div class="fx-carousel"><div class="fx-track">{cards}{cards}</div></div>
    """


def build_stepper_html(current_step: str, status: str = "", progress: int = 0, status_label: str = "") -> str:
    """复现流程步进器：已完成节点连线弹性填充、当前节点果冻弹跳。

    failed 状态：定位到失败步骤并标红（不让步进器退回第一步造成“卡住”假象）。
    """
    order = [step_id for step_id, _, _ in PIPELINE_STEPS]
    failed = str(status).lower() == "failed"
    current_idx = order.index(current_step) if current_step in order else 0

    nodes: List[str] = []
    for idx, (step_id, title, icon) in enumerate(PIPELINE_STEPS):
        if failed and idx == current_idx:
            state = "error"
        elif idx < current_idx or (failed and idx < current_idx):
            state = "done"
        elif idx == current_idx:
            state = "active"
        else:
            state = ""
        bar = "" if idx == 0 else "<div class='bar'></div>"
        nodes.append(
            f"<div class='fx-step {state}'><div class='node'>{icon}</div>{bar}"
            f"<div class='cap'>{title}</div></div>"
        )

    progress = max(0, min(100, int(progress)))
    meta_html = (
        f"<div class='fx-stepper-meta'>"
        f"<span class='meta-pill'>{status_label or '待开始'}</span>"
        f"<span class='meta-pill'>阶段 <b>{current_idx + 1}</b> / {len(order)}</span>"
        f"<span class='meta-pill'>进度 <b>{progress}%</b></span>"
        f"</div>"
    ) if status or progress else ""

    return f"<div class='fx-stepper'>{''.join(nodes)}</div>{meta_html}"
