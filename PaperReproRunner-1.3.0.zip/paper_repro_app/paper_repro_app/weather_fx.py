"""本地天气粒子特效：IP 定位 → Open-Meteo 免费天气接口 → 前端 Canvas 粒子。

- 定位使用 ip-api.com（免费、免 key），天气使用 open-meteo.com（免费、免 key）
- 结果缓存 30 分钟，离线/失败时优雅降级（返回 None → 不显示粒子）
- 所有网络请求超时严格限制，绝不阻塞页面
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, Optional

import requests

from paper_repro_app.paths import APP_HOME

CACHE_FILE = APP_HOME / "weather_cache.json"
CACHE_TTL = 30 * 60  # 30 分钟
HTTP_TIMEOUT = 5.0

# WMO 天气代码 → (粒子类型, 中文名, 白天 emoji, 夜晚 emoji)
WMO_MAP: dict[int, tuple[str, str, str, str]] = {
    0: ("clear", "晴", "☀️", "🌙"),
    1: ("clear", "大部晴朗", "🌤️", "🌙"),
    2: ("cloudy", "局部多云", "⛅", "☁️"),
    3: ("cloudy", "阴", "☁️", "☁️"),
    45: ("fog", "雾", "🌫️", "🌫️"),
    48: ("fog", "冻雾", "🌫️", "🌫️"),
    51: ("rain", "毛毛雨", "🌦️", "🌧️"),
    53: ("rain", "毛毛雨", "🌦️", "🌧️"),
    55: ("rain", "毛毛雨", "🌦️", "🌧️"),
    56: ("rain", "冻毛毛雨", "🌧️", "🌧️"),
    57: ("rain", "冻毛毛雨", "🌧️", "🌧️"),
    61: ("rain", "小雨", "🌧️", "🌧️"),
    63: ("rain", "中雨", "🌧️", "🌧️"),
    65: ("heavy_rain", "大雨", "🌧️", "🌧️"),
    66: ("rain", "冻雨", "🌧️", "🌧️"),
    67: ("heavy_rain", "冻雨", "🌧️", "🌧️"),
    71: ("snow", "小雪", "🌨️", "🌨️"),
    73: ("snow", "中雪", "🌨️", "🌨️"),
    75: ("snow", "大雪", "❄️", "❄️"),
    77: ("snow", "雪粒", "🌨️", "🌨️"),
    80: ("rain", "阵雨", "🌦️", "🌧️"),
    81: ("rain", "阵雨", "🌦️", "🌧️"),
    82: ("heavy_rain", "强阵雨", "⛈️", "⛈️"),
    85: ("snow", "阵雪", "🌨️", "🌨️"),
    86: ("snow", "阵雪", "🌨️", "🌨️"),
    95: ("storm", "雷暴", "⛈️", "⛈️"),
    96: ("storm", "雷暴伴冰雹", "⛈️", "⛈️"),
    99: ("storm", "雷暴伴冰雹", "⛈️", "⛈️"),
}


def _read_cache() -> Optional[dict]:
    try:
        if not CACHE_FILE.exists():
            return None
        data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        if time.time() - data.get("ts", 0) < CACHE_TTL:
            return data
    except (OSError, ValueError):
        pass
    return None


def _write_cache(data: dict) -> None:
    try:
        data = dict(data)
        data["ts"] = time.time()
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def _fetch_location() -> Optional[dict]:
    try:
        resp = requests.get(
            "http://ip-api.com/json/?fields=status,lat,lon,city,countryCode",
            timeout=HTTP_TIMEOUT,
            headers={"User-Agent": "paper-repro-runner/1.0"},
        )
        data = resp.json()
        if data.get("status") != "success" or not data.get("lat") or not data.get("lon"):
            return None
        return {"lat": data["lat"], "lon": data["lon"], "city": data.get("city", "")}
    except Exception:
        return None


def _fetch_weather(lat: float, lon: float) -> Optional[dict]:
    try:
        url = (
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            "&current=temperature_2m,weather_code,is_day,wind_speed_10m"
            "&timezone=auto"
        )
        resp = requests.get(url, timeout=HTTP_TIMEOUT)
        current = resp.json().get("current") or {}
        return {
            "code": int(current.get("weather_code", 0)),
            "temp": float(current.get("temperature_2m", 0)),
            "is_day": bool(current.get("is_day", 1)),
            "wind": float(current.get("wind_speed_10m", 0)),
        }
    except Exception:
        return None


def get_weather() -> Optional[dict]:
    """获取本地天气（带 30 分钟缓存）。失败返回 None。"""
    cached = _read_cache()
    if cached:
        return cached

    location = _fetch_location()
    if not location:
        return None

    weather = _fetch_weather(location["lat"], location["lon"])
    if not weather:
        return None

    result = {**location, **weather}
    _write_cache(result)
    return result


def describe(weather: Optional[dict]) -> dict:
    """把天气数据翻译成展示与粒子配置。"""
    if not weather:
        return {
            "kind": "calm",
            "label": "天气未知",
            "emoji": "🍃",
            "city": "",
            "temp": None,
            "html": "",
        }
    code = int(weather.get("code", 0))
    is_day = bool(weather.get("is_day", 1))
    kind, label, _day_emoji, _night_emoji = WMO_MAP.get(code, ("clear", "晴", "", ""))
    return {
        "kind": kind,
        "label": label,
        "emoji": "",
        "city": weather.get("city", ""),
        "temp": weather.get("temp"),
        "wind": weather.get("wind"),
    }


def _canvas_js(kind: str) -> str:
    """生成 Canvas 粒子动画脚本（在父文档 body 上绘制，pointer-events: none）。"""
    # 各天气粒子参数（透明度刻意压低：粒子只是氛围，不能干扰内容阅读）
    configs = {
        "clear": ("moties", 18, "#f6c177", 0.30),
        "cloudy": ("clouds", 4, "#ffffff", 0.32),
        "fog": ("fog", 3, "#ffffff", 0.22),
        "rain": ("rain", 50, "#5aa8c8", 0.22),
        "heavy_rain": ("rain", 80, "#5aa8c8", 0.30),
        "storm": ("storm", 70, "#5aa8c8", 0.30),
        "snow": ("snow", 30, "#ffffff", 0.42),
        "calm": ("moties", 12, "#a8d8c8", 0.22),
    }
    particle_type, count, color, alpha = configs.get(kind, configs["calm"])
    return f"""
<script>
(function () {{
  var parent = window.parent.document;
  if (parent.getElementById('pr-weather-canvas')) {{ return; }}
  var canvas = document.createElement('canvas');
  canvas.id = 'pr-weather-canvas';
  canvas.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:-1;opacity:0.55;';
  parent.body.appendChild(canvas);
  var ctx = canvas.getContext('2d');
  var W = 0, H = 0, DPR = Math.min(2, window.devicePixelRatio || 1);
  function resize() {{
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * DPR; canvas.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }}
  window.addEventListener('resize', resize);
  resize();

  var type = '{particle_type}', color = '{color}', alpha = {alpha}, N = {count};
  var items = [];
  function spawn(i) {{
    if (type === 'rain' || type === 'storm') {{
      return {{ x: Math.random() * W, y: Math.random() * H, len: 8 + Math.random() * 14,
               speed: 7 + Math.random() * 9, drift: -0.8 + Math.random() * 0.5, a: 0.15 + Math.random() * alpha }};
    }}
    if (type === 'snow') {{
      return {{ x: Math.random() * W, y: Math.random() * H, r: 1.5 + Math.random() * 3.2,
               speed: 0.6 + Math.random() * 1.6, sway: Math.random() * Math.PI * 2, a: 0.25 + Math.random() * alpha }};
    }}
    if (type === 'moties') {{
      return {{ x: Math.random() * W, y: H + Math.random() * H, r: 1 + Math.random() * 3,
               speed: 0.25 + Math.random() * 0.6, sway: Math.random() * Math.PI * 2, a: 0.12 + Math.random() * alpha }};
    }}
    if (type === 'clouds') {{
      return {{ x: Math.random() * W, y: H * (0.08 + Math.random() * 0.45), r: 60 + Math.random() * 90,
               speed: 0.2 + Math.random() * 0.45, a: 0.12 + Math.random() * alpha * 0.6 }};
    }}
    return {{ x: Math.random() * W, y: H * (0.15 + Math.random() * 0.6), w: 260 + Math.random() * 320,
              speed: 0.15 + Math.random() * 0.35, a: 0.1 + Math.random() * alpha * 0.5 }};
  }}
  for (var i = 0; i < N; i++) {{ items.push(spawn(i)); }}

  var flash = 0;
  function tick() {{
    ctx.clearRect(0, 0, W, H);
    var i, p;
    for (i = 0; i < items.length; i++) {{
      p = items[i];
      if (type === 'rain' || type === 'storm') {{
        p.y += p.speed; p.x += p.drift;
        if (p.y > H + 20) {{ p.y = -20; p.x = Math.random() * W; }}
        ctx.strokeStyle = 'rgba(90,168,200,' + p.a + ')';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - p.drift * 2.4, p.y - p.len);
        ctx.stroke();
      }} else if (type === 'snow') {{
        p.sway += 0.016; p.y += p.speed; p.x += Math.sin(p.sway) * 0.6;
        if (p.y > H + 10) {{ p.y = -10; p.x = Math.random() * W; }}
        ctx.fillStyle = 'rgba(255,255,255,' + p.a + ')';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }} else if (type === 'moties') {{
        p.sway += 0.012; p.y -= p.speed; p.x += Math.sin(p.sway) * 0.4;
        if (p.y < -12) {{ p.y = H + 12; p.x = Math.random() * W; }}
        ctx.fillStyle = 'rgba(246,193,119,' + p.a + ')';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }} else if (type === 'clouds') {{
        p.x += p.speed;
        if (p.x > W + p.r * 2.4) {{ p.x = -p.r * 2.4; p.y = H * (0.08 + Math.random() * 0.45); }}
        ctx.fillStyle = 'rgba(255,255,255,' + p.a + ')';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.arc(p.x + p.r * 0.7, p.y - p.r * 0.22, p.r * 0.72, 0, Math.PI * 2);
        ctx.arc(p.x - p.r * 0.7, p.y + p.r * 0.1, p.r * 0.6, 0, Math.PI * 2);
        ctx.fill();
      }} else {{ // fog
        p.x += p.speed;
        if (p.x - p.w / 2 > W) {{ p.x = -p.w / 2; }}
        var g = ctx.createRadialGradient(p.x, p.y, 4, p.x, p.y, p.w / 2);
        g.addColorStop(0, 'rgba(255,255,255,' + p.a + ')');
        g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g;
        ctx.fillRect(p.x - p.w / 2, p.y - 40, p.w, 80);
      }}
    }}
    if (type === 'storm') {{
      if (flash > 0) {{
        flash -= 0.06;
        ctx.fillStyle = 'rgba(255,255,255,' + Math.max(0, flash) * 0.35 + ')';
        ctx.fillRect(0, 0, W, H);
      }} else if (Math.random() < 0.004) {{
        flash = 1;
      }}
    }}
    requestAnimationFrame(tick);
  }}
  tick();
}})();
</script>
"""


def build_particles_html(weather: Optional[dict]) -> str:
    """返回用于 st.components.v1.html 的粒子特效 HTML。"""
    info = describe(weather)
    return f"""<div style="display:none;">weather-fx</div>{_canvas_js(info['kind'])}"""
