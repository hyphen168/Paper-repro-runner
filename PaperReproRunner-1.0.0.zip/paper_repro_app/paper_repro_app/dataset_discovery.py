from __future__ import annotations

import base64
import json
from typing import Any, Dict


_HELPER_PRELUDE = """import os as _os, sys as _sys
from pathlib import Path as _Path
try:
    yaml
except NameError:
    try:
        import yaml as _yaml_lib
        _cfg = _os.environ.get('PAPER_REPRO_HELPER_CONFIG', '')
        _raw = _Path(_cfg).read_text(encoding='utf-8') if _cfg and _Path(_cfg).exists() else ''
        if _raw: yaml = _yaml_lib.safe_load(_raw) or {}
        else: yaml = {}
    except Exception:
        yaml = {}
"""


class DatasetDiscovery:
    """Build a self-contained remote resolver for repository-declared datasets."""

    result_marker = "PAPER_REPRO_DATASET_JSON="
    env_file_name = ".paper_repro_dataset.env"

    @classmethod
    def build_remote_script(cls) -> str:
        return (
            "import base64, json, os, re, shutil, subprocess, sys, tarfile, urllib.request, zipfile\n"
            "from pathlib import Path\n"
            "try:\n"
            "    import yaml\n"
            "except ImportError as exc:\n"
            "    raise SystemExit('数据集解析需要 PyYAML：' + str(exc))\n"
            "root = Path.cwd()\n"
            "requested = sys.argv[1].strip()\n"
            "def load_candidate(path):\n"
            "    try:\n"
            "        value = yaml.safe_load(path.read_text(encoding='utf-8')) or {}\n"
            "    except (OSError, UnicodeDecodeError, yaml.YAMLError): return None\n"
            "    if not isinstance(value, dict) or not value.get('train') or not value.get('val'): return None\n"
            "    return value\n"
            "if requested:\n"
            "    config_path = Path(requested).expanduser()\n"
            "    if not config_path.is_absolute(): config_path = root / config_path\n"
            "    config_path = config_path.resolve()\n"
            "    config = load_candidate(config_path)\n"
            "    if config is None: raise SystemExit('指定的数据集 YAML 无效或缺少 train/val：' + str(config_path))\n"
            "else:\n"
            "    candidates = []\n"
            "    for path in root.rglob('*'):\n"
            "        if path.suffix.lower() not in {'.yaml', '.yml'} or any(part in {'.git', '.venv', 'venv'} for part in path.parts): continue\n"
            "        config = load_candidate(path)\n"
            "        if config is not None: candidates.append((0 if config.get('download') else 1, path, config))\n"
            "    if not candidates:\n"
            "        readmes = list(root.glob('README*'))\n"
            "        links = []\n"
            "        for readme in readmes:\n"
            "            links.extend(re.findall(r'https?://[^\\s)\\]\"<>]+', readme.read_text(encoding='utf-8', errors='ignore')))\n"
            "        dataset_links = [link for link in links if re.search(r'(dataset|data|\\.zip|\\.tar)', link, re.I)]\n"
            "        hint = ('；仓库 README 中发现候选链接：' + ', '.join(dataset_links[:3])) if dataset_links else ''\n"
            "        raise SystemExit('未发现包含 train/val 的数据集 YAML，无法安全自动配置数据集' + hint)\n"
            "    _, config_path, config = sorted(candidates, key=lambda item: (item[0], str(item[1])))[0]\n"
            "base = Path(str(config.get('path') or '.')).expanduser()\n"
            "if not base.is_absolute(): base = (config_path.parent / base).resolve()\n"
            "splits = []\n"
            "for key in ('train', 'val'):\n"
            "    value = config[key]\n"
            "    if isinstance(value, str): splits.append(base / value)\n"
            "    elif isinstance(value, list): splits.extend(base / item for item in value if isinstance(item, str))\n"
            "complete = bool(splits) and all(path.exists() for path in splits)\n"
            "download = config.get('download')\n"
            "if not complete:\n"
            "    if not isinstance(download, str) or not download.strip():\n"
            "        raise SystemExit('已识别数据集 YAML，但数据集缺失且仓库未声明官方下载指令：' + str(config_path))\n"
            "    print('数据集缺失，执行仓库 YAML 声明的官方下载来源。')\n"
            "    if download.startswith(('http://', 'https://')):\n"
            "        archive = base.parent / Path(download.split('?', 1)[0]).name\n"
            "        base.parent.mkdir(parents=True, exist_ok=True)\n"
            "        urllib.request.urlretrieve(download, archive)\n"
            "        if zipfile.is_zipfile(archive):\n"
            "            with zipfile.ZipFile(archive) as bundle: bundle.extractall(base.parent)\n"
            "        elif tarfile.is_tarfile(archive):\n"
            "            with tarfile.open(archive) as bundle: bundle.extractall(base.parent, filter='data')\n"
            "        else: raise SystemExit('数据集下载地址不是支持的 ZIP/TAR 包：' + str(archive))\n"
            "        archive.unlink(missing_ok=True)\n"
            "    else:\n"
            "        is_python_code = any(download.lstrip().startswith(kw) for kw in ('import ', 'from ', '#', '\\nimport', '\\nfrom')) or '\\nimport ' in download or '\\nfrom ' in download\n"
            "        if is_python_code:\n"
            "            temp_py = root / '.paper_repro_download_helper.py'\n"
            "            # 仓库脚本常假设运行在已加载 YAML 字典的上下文中（如 yaml['path']），\n"
            "            # 独立执行会 NameError；注入兜底：未定义 yaml 时从声明下载指令的配置加载为字典\n"
            "            prelude = " + repr(_HELPER_PRELUDE) + "\n"
            "            temp_py.write_text(prelude + download, encoding='utf-8')\n"
            "            py_exec = sys.executable if sys.executable else 'python'\n"
            "            try:\n"
            "                helper_env = dict(os.environ)\n"
            "                helper_env['PAPER_REPRO_HELPER_CONFIG'] = str(config_path)\n"
            "                result = subprocess.run([py_exec, str(temp_py)], cwd=root, capture_output=True, text=True, check=False, env=helper_env)\n"
            "            finally:\n"
            "                temp_py.unlink(missing_ok=True)\n"
            "        else:\n"
            "            result = subprocess.run(download, shell=True, cwd=root, capture_output=True, text=True, check=False)\n"
            "        stderr_msg = ''\n"
            "        if hasattr(result, 'stderr') and result.stderr:\n"
            "            stderr_msg = result.stderr.strip()\n"
            "        if result.returncode:\n"
            "            hint = ('\\n--- stderr ---\\n' + stderr_msg) if stderr_msg else ''\n"
            "            raise SystemExit(f'仓库数据集下载脚本失败（退出码 {result.returncode}）{hint}')\n"
            "    if not all(path.exists() for path in splits):\n"
            "        raise SystemExit('下载后未找到 YAML 声明的 train/val 路径：' + ', '.join(str(path) for path in splits))\n"
            "relative_config = str(config_path.relative_to(root)) if config_path.is_relative_to(root) else str(config_path)\n"
            "env_path = root / '.paper_repro_dataset.env'\n"
            "env_path.write_text('export PAPER_REPRO_DATA_CONFIG=' + json.dumps(relative_config) + '\\n', encoding='utf-8')\n"
            "payload = {'config_path': relative_config, 'dataset_root': str(base), 'downloaded': not complete, 'splits': [str(path) for path in splits]}\n"
            "print('PAPER_REPRO_DATASET_JSON=' + base64.b64encode(json.dumps(payload).encode('utf-8')).decode('ascii'))"
        )

    @classmethod
    def build_remote_command(cls, python_bin: str, data_config: str) -> str:
        encoded = base64.b64encode(cls.build_remote_script().encode("utf-8")).decode("ascii")
        # 落盘执行：先写 .dep_dataset.py 再执行脚本文件，与 dependencies 步骤的
        # .dep_scan.py 模式一致，彻底规避 bash 内联解析截断风险
        return (
            f"{python_bin} -c \"from pathlib import Path; import base64; "
            f"Path('.dep_dataset.py').write_text(base64.b64decode('{encoded}').decode('utf-8'), encoding='utf-8')\""
            f" && {python_bin} .dep_dataset.py {data_config!r}"
        )

    @classmethod
    def extract_payload(cls, log_text: str) -> Dict[str, Any]:
        for line in reversed(log_text.splitlines()):
            if not line.startswith(cls.result_marker):
                continue
            try:
                return json.loads(base64.b64decode(line[len(cls.result_marker):]).decode("utf-8"))
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                return {}
        return {}
