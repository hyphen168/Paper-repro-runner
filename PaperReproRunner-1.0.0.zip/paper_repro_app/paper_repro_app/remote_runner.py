from __future__ import annotations

import json
import base64
import os
import shlex
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Dict, List

from paper_repro_app.dataset_discovery import DatasetDiscovery
from paper_repro_app.model_discovery import ModelDiscovery

try:
    from paper_repro_app.logging_config import get_logger
    logger = get_logger("remote_runner")
except ImportError:  # pragma: no cover
    import logging
    logger = logging.getLogger("remote_runner")

try:
    from paper_repro_app.logger_utils import (
        StepLogger,
        build_trace_id_from_task,
        enrich_log_for_display,
        make_trace_id,
    )
except ImportError:
    StepLogger = None
    build_trace_id_from_task = None
    enrich_log_for_display = lambda x: x
    make_trace_id = lambda: "task-unknown"

try:
    import paramiko
except ImportError:  # pragma: no cover
    paramiko = None


class RemoteStepError(RuntimeError):
    """A remote command failure that cannot be resolved by reconnecting."""


def _is_auth_exception(exc: BaseException) -> bool:
    """判断是否为 SSH 认证类失败（Authentication failed 一族）。

    认证失败意味着凭据/配置本身有问题，重试无意义；同时不同 paramiko
    版本对异常类的顶层导出位置有差异，这里逐项 getattr 容错，避免漏判。
    """
    if paramiko is None:
        return False
    for name in (
        "AuthenticationException",
        "BadAuthenticationType",
        "PartialAuthentication",
        "PasswordRequiredException",
    ):
        cls = getattr(paramiko, name, None)
        if cls is not None and isinstance(exc, cls):
            return True
    return False


class RemoteRunner:
    def __init__(self, task: Dict[str, Any], max_retries: int = 2):
        self.task = task
        self.host = task.get("host")
        self.user = task.get("user")
        self.ssh_key_path = task.get("ssh_key_path")
        self.password = task.get("password")
        self.port = task.get("port") or task.get("ssh_port") or 22
        self.remote_workdir = task.get("remote_workdir", "/workspace/paper-repro")
        self.repo_url = task.get("repo_url")
        self.clone_url = task.get("clone_url") or self.repo_url
        self.pip_index_url = task.get("pip_index_url", "").strip()
        self.env_mode = task.get("environment_mode", "conda")
        self.max_retries = max_retries
        self.command_timeout = int(task.get("command_timeout", 900))
        self.clone_timeout = int(task.get("clone_timeout", 600))
        self.auto_run = bool(task.get("auto_run", False))

        # --- 日志增强: trace_id + 命令回放 ---
        tid = build_trace_id_from_task(task) if build_trace_id_from_task else None
        self._trace_id = tid or make_trace_id()
        self._log = StepLogger(logger, self._trace_id) if StepLogger else None

    @staticmethod
    def extract_collection_payload(log_text: str) -> Dict[str, Any]:
        """Decode the bounded result manifest emitted by the remote collect step."""
        marker = "PAPER_REPRO_RESULTS_JSON="
        for line in reversed(log_text.splitlines()):
            if not line.startswith(marker):
                continue
            try:
                return json.loads(base64.b64decode(line[len(marker):]).decode("utf-8"))
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                return {}
        return {}

    def normalize_ssh_key_reference(self, key_value: Any) -> str:
        if key_value is None:
            return ""
        value = str(key_value).strip()
        if not value:
            return ""
        if value.startswith("-----BEGIN") or "PRIVATE KEY" in value.upper():
            ssh_dir = Path.home() / ".ssh" / "auto_generated"
            ssh_dir.mkdir(parents=True, exist_ok=True)
            key_file = ssh_dir / f"paper_repro_{abs(hash(value))}.key"
            if not key_file.exists() or key_file.read_text(encoding="utf-8", errors="replace") != value:
                key_file.write_text(value, encoding="utf-8")
            os.chmod(key_file, 0o600)
            return str(key_file)
        expanded = os.path.expanduser(value)
        if expanded and os.path.isfile(expanded):
            return expanded
        return ""

    def detect_ssh_auth_sources(self) -> Dict[str, Any]:
        ssh_dir = Path.home() / ".ssh"
        key_candidates = []
        primary_key = self.normalize_ssh_key_reference(self.ssh_key_path)
        if primary_key:
            key_candidates.append(primary_key)
        for candidate in [
            ssh_dir / "id_rsa",
            ssh_dir / "id_ed25519",
            ssh_dir / "id_ecdsa",
        ]:
            if candidate.exists() and str(candidate) not in key_candidates:
                key_candidates.append(str(candidate))

        agent_keys = []
        try:
            result = subprocess.run(["ssh-add", "-L"], capture_output=True, text=True, check=False)
            if result.stdout:
                agent_keys = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        except FileNotFoundError:
            agent_keys = []

        config_path = ssh_dir / "config"
        config_identity = []
        if config_path.exists():
            try:
                for line in config_path.read_text(encoding="utf-8", errors="replace").splitlines():
                    if line.strip().lower().startswith("identityfile"):
                        value = line.split(None, 1)[1].strip()
                        if value:
                            config_identity.append(os.path.expanduser(value))
            except OSError:
                config_identity = []

        resolved_key = key_candidates[0] if key_candidates else None
        return {
            "key_candidates": key_candidates,
            "agent_keys": agent_keys,
            "config_identity": config_identity,
            "resolved_key": resolved_key,
            "has_any_auth": bool(key_candidates or agent_keys or config_identity),
        }

    def build_pipeline(self) -> List[Dict[str, str]]:
        conda_bootstrap = (
            "CONDA_BIN=$(command -v conda 2>/dev/null || true); "
            "if [ -z \"$CONDA_BIN\" ]; then "
            "for candidate in /root/miniconda3/bin/conda /opt/conda/bin/conda "
            "$HOME/miniconda3/bin/conda $HOME/anaconda3/bin/conda /root/anaconda3/bin/conda; do "
            "if [ -x \"$candidate\" ]; then CONDA_BIN=$candidate; break; fi; "
            "done; fi; "
            "if [ -n \"$CONDA_BIN\" ]; then export PATH=\"$(dirname \"$CONDA_BIN\"):$PATH\"; fi"
        )
        configured_pip_index = shlex.quote(self.pip_index_url) if self.pip_index_url else ""
        pip_install_helper = (
            "pip_install_with_fallback() { "
            "export PIP_CACHE_DIR=\"${PIP_CACHE_DIR:-$HOME/.cache/pip}\"; mkdir -p \"$PIP_CACHE_DIR\"; "
            f"candidates=\"{configured_pip_index} https://pypi.tuna.tsinghua.edu.cn/simple https://mirrors.aliyun.com/pypi/simple https://pypi.org/simple\"; "
            "installed=0; "
            "for index in $candidates; do "
            "[ -n \"$index\" ] || continue; "
            "echo \"尝试依赖源：$index\"; "
            "if timeout 120 python -m pip install --disable-pip-version-check --prefer-binary --cache-dir \"$PIP_CACHE_DIR\" --index-url \"$index\" \"$@\"; then "
            "echo \"依赖安装成功（源：$index）\"; installed=1; break; "
            "fi; "
            "echo \"当前依赖源安装失败或超时，自动切换下一个备用源重试...\"; "
            "done; "
            "[ $installed -eq 1 ] || return 0; "
            "}; "
        )
        dependency_script = (
            "import ast, importlib.util, sys\n"
            "from pathlib import Path\n"
            "root = Path('.')\n"
            "local_modules = {path.stem for path in root.glob('*.py')}\n"
            "local_modules.update(path.name for path in root.iterdir() if path.is_dir() and (path / '__init__.py').exists())\n"
            "skip = set(sys.stdlib_module_names) | local_modules | {'__future__'}\n"
            "imports = set()\n"
            "for path in root.rglob('*.py'):\n"
            "    if any(part in {'.git', '.venv', 'venv', 'build', 'dist'} for part in path.parts): continue\n"
            "    try: tree = ast.parse(path.read_text(encoding='utf-8', errors='ignore'))\n"
            "    except (OSError, SyntaxError): continue\n"
            "    for node in ast.walk(tree):\n"
            "        if isinstance(node, ast.Import): imports.update(alias.name.split('.')[0] for alias in node.names)\n"
            "        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module: imports.add(node.module.split('.')[0])\n"
            "mapping = {'cv2': 'opencv-python', 'PIL': 'pillow', 'yaml': 'pyyaml', 'sklearn': 'scikit-learn', 'Crypto': 'pycryptodome', 'flask': 'flask', 'pytest': 'pytest', 'pytest_cov': 'pytest-cov'}\n"
            "missing = sorted(name for name in imports if name not in skip and importlib.util.find_spec(name) is None)\n"
            "packages = [mapping[name] for name in missing if name in mapping]\n"
            "skipped = [name for name in missing if name not in mapping]\n"
            "if skipped: print('OPTIONAL_OR_UNMAPPED_IMPORTS=' + ' '.join(skipped))\n"
            "print('AUTO_DISCOVERED_PACKAGES=' + ' '.join(packages))"
        )
        env_step = (
            f"{conda_bootstrap}; "
            # 1) 探测系统 Python（而非硬编码 python3）
            "SYSTEM_PYTHON=$(command -v python3 || command -v python || true); "
            "if [ -n \"$CONDA_BIN\" ] && [ \"{mode}\" = \"conda\" ]; then "
            "eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
            "conda activate paper-repro >/dev/null 2>&1 || \"$CONDA_BIN\" create -y -n paper-repro python=3.10 >/dev/null 2>&1; "
            "conda activate paper-repro || {{ echo 'Conda 环境激活失败，请检查云端 Conda 安装'; exit 1; }}; "
            "python --version; "
            "else "
            "echo '未检测到可用 Conda，自动回退到 Python venv'; "
            # 2) 系统无 Python 时自动安装 Miniconda（清华镜像），失败给出可读指引
            "if [ -z \"$SYSTEM_PYTHON\" ]; then "
            "echo '未找到系统 Python，尝试自动安装 Miniconda（清华镜像）...'; "
            "curl -fsSL --connect-timeout 20 --max-time 600 'https://mirrors.tuna.tsinghua.edu.cn/anaconda/miniconda/Miniconda3-latest-Linux-x86_64.sh' -o /tmp/miniconda.sh || "
            "{{ echo 'Miniconda 下载失败：请手动下载 https://mirrors.tuna.tsinghua.edu.cn/anaconda/miniconda/Miniconda3-latest-Linux-x86_64.sh 并执行 bash 安装后重试'; exit 1; }}; "
            "bash /tmp/miniconda.sh -b -p \"$HOME/miniconda3\" >/dev/null 2>&1 || "
            "{{ echo 'Miniconda 安装失败：请手动安装 Miniconda 后重试'; exit 1; }}; "
            "export PATH=\"$HOME/miniconda3/bin:$PATH\"; "
            "CONDA_BIN=\"$HOME/miniconda3/bin/conda\"; "
            "\"$CONDA_BIN\" create -y -n paper-repro python=3.10 >/dev/null 2>&1 || {{ echo 'Conda 环境创建失败'; exit 1; }}; "
            "eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
            "conda activate paper-repro || {{ echo 'Conda 环境激活失败'; exit 1; }}; "
            "python --version; "
            "else "
            # 3) 有系统 Python：优先 venv，失败则直接用系统 Python，未找到时报可读错误
            "echo \"使用系统 Python: $SYSTEM_PYTHON\"; "
            "if \"$SYSTEM_PYTHON\" -m venv .venv >/dev/null 2>&1; then "
            "echo 'Python venv 创建成功'; "
            "else "
            "echo '虚拟环境创建失败（可能缺少 ensurepip），将直接使用系统 Python'; "
            "fi; "
            "if [ -f .venv/bin/activate ]; then . .venv/bin/activate; fi; "
            "PYTHON_BIN=\"$PWD/.venv/bin/python\"; "
            "[ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=\"$SYSTEM_PYTHON\"; "
            "if command -v \"$PYTHON_BIN\" >/dev/null 2>&1; then \"$PYTHON_BIN\" --version; "
            "else echo '未找到可用的 Python 解释器，请先安装 Python 3.10+ 或 Miniconda 后重试'; exit 1; fi; "
            "fi; "  # 内层 if [ -z "$SYSTEM_PYTHON" ] 闭合
            "fi"    # 外层 if [ -n "$CONDA_BIN" ] && [ mode = conda ] 闭合（缺失会导致 bash: unexpected end of file）
        ).format(mode=shlex.quote(self.env_mode))
        install_step = (
            "cd {workdir} && {conda_bootstrap}; "
            "{pip_install_helper}"
            "if [ -n \"$CONDA_BIN\" ] && [ \"{mode}\" = \"conda\" ]; then "
            "eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
            "conda activate paper-repro >/dev/null 2>&1; "
            "if [ -f environment.yml ]; then echo '发现 environment.yml，更新 Conda 环境'; conda env update -f environment.yml --prune; fi; "
            "if [ -f requirements.txt ]; then echo '发现 requirements.txt，安装声明依赖'; pip_install_with_fallback -r requirements.txt; fi; "
            "if [ -f setup.py ] || [ -f pyproject.toml ]; then echo '发现 Python 项目配置，安装项目依赖'; pip_install_with_fallback -e .; fi; "
            "else "
            "SYSTEM_PYTHON=python3; "
            "python3 --version >/dev/null 2>&1 || SYSTEM_PYTHON=python; "
            "if [ -f .venv/bin/activate ]; then . .venv/bin/activate; fi; "
            "PYTHON_BIN=\"$PWD/.venv/bin/python\"; "
            "[ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=\"$SYSTEM_PYTHON\"; "
            "[ -n \"$PYTHON_BIN\" ] || {{ echo '未找到 Python 可执行文件'; exit 127; }}; "
            "\"$PYTHON_BIN\" -m pip install --disable-pip-version-check --upgrade pip && "
            "if [ -f requirements.txt ]; then echo '发现 requirements.txt，安装声明依赖'; pip_install_with_fallback -r requirements.txt; fi && "
            "if [ -f setup.py ] || [ -f pyproject.toml ]; then echo '发现 Python 项目配置，安装项目依赖'; pip_install_with_fallback -e .; fi; "
            "fi"
        ).format(
            workdir=f"{self.remote_workdir}/repo",
            mode=self.env_mode,
            conda_bootstrap=conda_bootstrap,
            pip_install_helper=pip_install_helper,
        )
        dep_scan_b64 = base64.b64encode(dependency_script.encode("utf-8")).decode("ascii")
        dependency_step = (
            f"cd {shlex.quote(str(self.remote_workdir))}/repo && "
            f"{conda_bootstrap}; "
            "SYSTEM_PYTHON=$(command -v python3 || command -v python || true); "
            "if [ -n \"$CONDA_BIN\" ] && [ "
            f"\"{self.env_mode}\" = \"conda\" ]; then eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; conda activate paper-repro; "
            "PYTHON_BIN=$(command -v python || true); "
            "else "
            "PYTHON_BIN=\"$PWD/.venv/bin/python\"; "
            "[ -f .venv/bin/activate ] && . .venv/bin/activate; "
            "[ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=\"$SYSTEM_PYTHON\"; "
            "fi; "
            # 落盘执行：先写 .dep_scan.py（用 Python base64 解码，不依赖远端 base64 命令），
            # 再执行脚本文件——彻底规避 bash 内联解析截断，脚本留档便于排查
            f"\"$PYTHON_BIN\" -c \"from pathlib import Path; import base64; Path('.dep_scan.py').write_text(base64.b64decode('{dep_scan_b64}').decode('utf-8'), encoding='utf-8')\"; "
            f"missing=$(\"$PYTHON_BIN\" .dep_scan.py | sed -n 's/^AUTO_DISCOVERED_PACKAGES=//p'); "
            "if [ -n \"$missing\" ]; then "
            "echo \"依赖清单未覆盖的基础运行 import，尝试补装：$missing\"; "
            f"$PYTHON_BIN -m pip install --disable-pip-version-check --prefer-binary {'--index-url ' + configured_pip_index if configured_pip_index else ''} $missing; "
            "else echo '依赖扫描完成：未发现可安全自动补装的基础运行 import。可选导出/部署依赖仅记录，不自动安装。'; fi; "
            "$PYTHON_BIN -m pip check || echo 'pip check 检测到依赖冲突，继续执行代码验证以便收集准确错误'"
        )
        configured_run_command = str(self.task.get("run_command") or "").strip()
        data_config = str(self.task.get("data_config") or "").strip()
        requires_dataset = bool(configured_run_command or self.auto_run)
        if requires_dataset and self.task.get("auto_download_dataset", True):
            dataset_step = (
                f"cd {shlex.quote(f'{self.remote_workdir}/repo')} && "
                f"{conda_bootstrap}; "
                "if [ -n \"$CONDA_BIN\" ] && [ \""
                f"{self.env_mode}"
                "\" = \"conda\" ]; then eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
                "conda activate paper-repro >/dev/null 2>&1; PYTHON_BIN=python; "
                "else PYTHON_BIN=\"$PWD/.venv/bin/python\"; [ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=python3; fi; "
                "echo '自动发现仓库数据集配置、复用缓存或执行官方下载'; "
                + DatasetDiscovery.build_remote_command("\"$PYTHON_BIN\"", data_config)
            )
        else:
            dataset_step = (
                f"cd {shlex.quote(str(self.remote_workdir))}/repo && "
                "echo '自动数据集下载已关闭；仅扫描仓库中的数据集配置。'; "
                "find data -maxdepth 2 -type f -name '*.yaml' -print 2>/dev/null || true"
            )
        verify_step = (
            "cd {workdir} && {conda_bootstrap}; "
            "if [ -n \"$CONDA_BIN\" ] && [ \"{mode}\" = \"conda\" ]; then "
            "eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
            "conda activate paper-repro >/dev/null 2>&1; "
            "PYTHON_BIN=python; "
            "else "
            "if [ -f .venv/bin/activate ]; then . .venv/bin/activate; fi; "
            "PYTHON_BIN=\"$PWD/.venv/bin/python\"; "
            "[ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=python3; fi; "
            "[ -n \"$PYTHON_BIN\" ] || {{ echo '未找到 Python 可执行文件，无法执行验证'; exit 127; }}; "
            "if [ -f pytest.ini ] || [ -d tests ]; then "
            "if ! \"$PYTHON_BIN\" -c 'import pytest' >/dev/null 2>&1; then "
            "echo '验证需要 pytest，使用共享 pip 缓存补装'; "
            "PIP_CACHE_DIR=\"$HOME/.cache/pip\"; mkdir -p \"$PIP_CACHE_DIR\"; "
            "\"$PYTHON_BIN\" -m pip install --disable-pip-version-check --cache-dir \"$PIP_CACHE_DIR\" pytest; "
            "fi; "
            "\"$PYTHON_BIN\" -m pytest -q --maxfail=1 -x; "
            "else \"$PYTHON_BIN\" -m compileall .; fi"
        ).format(
            workdir=f"{self.remote_workdir}/repo",
            mode=self.env_mode,
            conda_bootstrap=conda_bootstrap,
        )
        model_step = (
        f"cd {shlex.quote(f'{self.remote_workdir}/repo')} && "
        f"{conda_bootstrap}; "
        "if [ -n \"$CONDA_BIN\" ] && [ \""
        f"{self.env_mode}"
        "\" = \"conda\" ]; then eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
        "conda activate paper-repro >/dev/null 2>&1; PYTHON_BIN=python; "
        "else PYTHON_BIN=\"$PWD/.venv/bin/python\"; [ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=python3; fi; "
        + ModelDiscovery.build_remote_command("\"$PYTHON_BIN\"")
        )
        if configured_run_command or self.auto_run:
            effective_run_command = configured_run_command or '"${PAPER_REPRO_AUTO_RUN_COMMAND}"'
            safe_run_command = shlex.quote(effective_run_command)
            run_step = (
                f"cd {shlex.quote(f'{self.remote_workdir}/repo')} && "
                f"{conda_bootstrap}; "
                "if [ -n \"$CONDA_BIN\" ] && [ \""
                f"{self.env_mode}"
                "\" = \"conda\" ]; then eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
                "conda activate paper-repro >/dev/null 2>&1; PYTHON_BIN=python; "
                "else PYTHON_BIN=\"$PWD/.venv/bin/python\"; "
                "[ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=python3; fi; "
                "echo '开始执行用户配置的实际模型命令'; "
                f"if [ -f {DatasetDiscovery.env_file_name} ]; then . {DatasetDiscovery.env_file_name}; fi; "
                f"if [ -f {ModelDiscovery.env_file_name} ]; then . {ModelDiscovery.env_file_name}; fi; "
                "if [ -z \"${PAPER_REPRO_AUTO_RUN_COMMAND:-}\" ] && [ -z \""
                + ("1" if configured_run_command else "")
                + "\" ]; then echo '未能自动推断训练命令，请在页面填写 README 中的训练命令。' >&2; exit 65; fi; "
                f"timeout {self.command_timeout} bash -lc {safe_run_command}"
            )
        else:
            run_step = (
                f"cd {shlex.quote(f'{self.remote_workdir}/repo')} && "
                f"{conda_bootstrap}; "
                "if [ -n \"$CONDA_BIN\" ] && [ \""
                f"{self.env_mode}"
                "\" = \"conda\" ]; then eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
                "conda activate paper-repro >/dev/null 2>&1; PYTHON_BIN=python; "
                "else PYTHON_BIN=\"$PWD/.venv/bin/python\"; "
                "[ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=python3; fi; "
                "ENTRYPOINT=''; "
                "for candidate in train.py detect.py predict.py main.py app.py; do "
                "if [ -f \"$candidate\" ]; then ENTRYPOINT=\"$candidate\"; break; fi; done; "
                "if [ -n \"$ENTRYPOINT\" ]; then "
                "echo \"自动识别模型入口：$ENTRYPOINT（执行启动参数检查）\"; "
                "\"$PYTHON_BIN\" \"$ENTRYPOINT\" --help >/dev/null; "
                "echo '模型入口可正常启动，已完成安全启动检查'; "
                "else echo '未识别到标准模型入口，已完成环境和代码验证；请在任务配置中提供 run_command。'; fi"
            )
        collection_script = (
            "import base64, csv, json\n"
            "from pathlib import Path\n"
            "root = Path('.')\n"
            "metric_tokens = ('map', 'precision', 'recall', 'f1', 'accuracy', 'acc', 'loss')\n"
            "metrics, sources, artifacts = {}, [], []\n"
            "for path in sorted(root.rglob('*')):\n"
            "    if any(part in {'.git', '.venv', 'venv', '__pycache__'} for part in path.parts) or not path.is_file(): continue\n"
            "    relative = str(path.relative_to(root))\n"
            "    name = path.name.lower()\n"
            "    if name in {'best.pt', 'last.pt'} or path.suffix.lower() in {'.png', '.jpg', '.jpeg'}:\n"
            "        if len(artifacts) < 50: artifacts.append(relative)\n"
            "    if name not in {'results.csv', 'metrics.csv', 'results.json', 'metrics.json'}: continue\n"
            "    try:\n"
            "        if path.suffix.lower() == '.csv':\n"
            "            rows = list(csv.DictReader(path.open(encoding='utf-8-sig', newline='')))\n"
            "            values = rows[-1] if rows else {}\n"
            "        else:\n"
            "            values = json.loads(path.read_text(encoding='utf-8'))\n"
            "            if isinstance(values, list): values = values[-1] if values else {}\n"
            "        if not isinstance(values, dict): continue\n"
            "        extracted = {}\n"
            "        for key, value in values.items():\n"
            "            if any(token in str(key).lower() for token in metric_tokens):\n"
            "                try: extracted[str(key)] = float(value)\n"
            "                except (TypeError, ValueError): pass\n"
            "        if extracted:\n"
            "            metrics.update(extracted); sources.append(relative)\n"
            "    except (OSError, ValueError, json.JSONDecodeError): continue\n"
            "payload = {'metrics': metrics, 'metric_sources': sources, 'artifacts': artifacts}\n"
            "print('PAPER_REPRO_RESULTS_JSON=' + base64.b64encode(json.dumps(payload, ensure_ascii=False).encode('utf-8')).decode('ascii'))"
        )
        collection_step = (
            f"cd {shlex.quote(f'{self.remote_workdir}/repo')} && "
            f"{conda_bootstrap}; "
            "if [ -n \"$CONDA_BIN\" ] && [ \""
            f"{self.env_mode}"
            "\" = \"conda\" ]; then eval \"$(\"$CONDA_BIN\" shell.bash hook 2>/dev/null || true)\"; "
            "conda activate paper-repro >/dev/null 2>&1; PYTHON_BIN=python; "
            "else PYTHON_BIN=\"$PWD/.venv/bin/python\"; [ -x \"$PYTHON_BIN\" ] || PYTHON_BIN=python3; fi; "
            "\"$PYTHON_BIN\" -c \"from pathlib import Path; import base64; Path('.collect_results.py').write_text(base64.b64decode('"
            + base64.b64encode(collection_script.encode("utf-8")).decode("ascii")
            + "').decode('utf-8'), encoding='utf-8')\"; "
            "\"$PYTHON_BIN\" .collect_results.py"
        )
        clone_source = shlex.quote(str(self.clone_url))
        workdir = shlex.quote(str(self.remote_workdir))
        clone_step = (
            f"cd {workdir} && export GIT_LFS_SKIP_SMUDGE=1 && "
            "export GIT_TERMINAL_PROMPT=0 && "
            "git config --global http.version HTTP/1.1 && "
            "git config --global http.lowSpeedLimit 1024 && "
            "git config --global http.lowSpeedTime 45 && "
            f"timeout 13 git ls-remote --heads {clone_source} >/dev/null || "
            "echo '代码源 13 秒内无响应：将尝试拉取；若网络超时，建议在界面填写公开的加速仓库地址。' >&2; "
            "if [ -d repo/.git ]; then "
            "cd repo && "
            "(git fetch --depth 1 --no-tags --progress origin && git reset --hard FETCH_HEAD && git clean -ffdx) || "
            f"(cd .. && rm -rf repo && timeout {self.clone_timeout} git clone --depth 1 --no-tags --filter=blob:none --single-branch --progress {clone_source} repo); "
            "else "
            f"timeout {self.clone_timeout} git clone --depth 1 --no-tags --filter=blob:none --single-branch --progress {clone_source} repo || "
            f"(rm -rf repo && timeout 120 git clone --depth 1 --no-tags --single-branch --progress {clone_source} repo); "
            "fi"
        )

        steps: List[Dict[str, str]] = [
            {"id": "prepare", "title": "准备工作目录", "command": f"mkdir -p {self.remote_workdir} >/dev/null 2>&1"},
            {"id": "clone", "title": "拉取论文代码仓库", "command": clone_step},
            {"id": "env", "title": "环境诊断与适配", "command": f"cd {self.remote_workdir}/repo && echo '--- 环境诊断 ---' && echo 'runner-python-fallback-v3' && python3 --version && ls -1 . 2>/dev/null | head && {env_step}"},
            {"id": "install", "title": "安装依赖", "command": install_step},
            {"id": "dependencies", "title": "扫描并补装缺失依赖", "command": dependency_step},
            {"id": "dataset", "title": "识别并准备数据集", "command": dataset_step},
            {"id": "verify", "title": "验证复现脚本", "command": verify_step},
            {"id": "model", "title": "识别模型训练入口", "command": model_step},
            {"id": "run", "title": "识别并启动模型", "command": run_step},
            {"id": "collect", "title": "收集指标与关键产物", "command": collection_step},
        ]
        return steps

    def build_plan(self) -> List[str]:
        return [step["command"] for step in self.build_pipeline()]

    def build_shell_script(self) -> str:
        script_lines = ["set -euo pipefail"]
        for step in self.build_pipeline():
            script_lines.append(f"echo '--- {step['title']} ---'")
            script_lines.append(step["command"])
        script_lines.append("echo '论文复现任务已进入云端执行阶段'")
        return "\n".join(script_lines)

    def detect_ssh_auth_sources(self) -> Dict[str, Any]:
        ssh_dir = Path.home() / ".ssh"
        key_candidates = []
        primary_key = self.normalize_ssh_key_reference(self.ssh_key_path)
        if primary_key:
            key_candidates.append(primary_key)
        for candidate in [
            ssh_dir / "id_rsa",
            ssh_dir / "id_ed25519",
            ssh_dir / "id_ecdsa",
        ]:
            if candidate.exists() and str(candidate) not in key_candidates:
                key_candidates.append(str(candidate))

        agent_keys = []
        try:
            result = subprocess.run(["ssh-add", "-L"], capture_output=True, text=True, check=False)
            if result.stdout:
                agent_keys = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        except FileNotFoundError:
            agent_keys = []

        config_path = ssh_dir / "config"
        config_identity = []
        if config_path.exists():
            try:
                for line in config_path.read_text(encoding="utf-8", errors="replace").splitlines():
                    if line.strip().lower().startswith("identityfile"):
                        value = line.split(None, 1)[1].strip()
                        if value:
                            config_identity.append(os.path.expanduser(value))
            except OSError:
                config_identity = []

        resolved_key = key_candidates[0] if key_candidates else None
        return {
            "key_candidates": key_candidates,
            "agent_keys": agent_keys,
            "config_identity": config_identity,
            "resolved_key": resolved_key,
            "has_any_auth": bool(key_candidates or agent_keys or config_identity),
        }

    def execute(
        self,
        on_step: Callable[[str, str, str], None] | None = None,
    ) -> Dict[str, Any]:
        if not self.host or not self.user:
            return {"status": "failed", "message": "云服务器连接信息不完整，请补充主机和用户名。"}

        if paramiko is None:
            return {"status": "failed", "message": "paramiko 未安装，请在本地运行 pip install paramiko。"}

        auth_state = self.detect_ssh_auth_sources()
        key_candidates = auth_state["key_candidates"]
        resolved_key = auth_state.get("resolved_key")
        login_methods = []
        if auth_state["has_any_auth"]:
            login_methods.append("key")
        if self.password:
            login_methods.append("password")
        if not login_methods:
            return {
                "status": "failed",
                "message": "服务器已启动，但本机没有可用 SSH 认证来源。请确认你已复制真实私钥内容或有效 key 文件路径，并且本机已可用 ssh-agent / ~/.ssh/config / IdentityFile。",
                "attempts": 0,
            }

        task_id = self.task.get("id", "unknown_task")
        self._log.info(f"开始在 {self.host}:{self.port} ({self.user}) 上执行远程复现流水线 (trace: {self._trace_id})")
        last_error = None
        for attempt in range(1, self.max_retries + 2):
            ssh = None
            try:
                self._log.info(f"第 {attempt} 次尝试建立 SSH 连接...")
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                has_specific_key = bool((resolved_key and os.path.exists(resolved_key)) or key_candidates)
                use_agent = not has_specific_key and not self.password

                connect_kwargs = {
                    "hostname": self.host,
                    "username": self.user,
                    "port": int(self.port) if str(self.port).isdigit() else 22,
                    "timeout": 30,
                    "banner_timeout": 60,
                    "auth_timeout": 60,
                    "allow_agent": use_agent,
                    "look_for_keys": use_agent,
                }
                if resolved_key and os.path.exists(resolved_key):
                    connect_kwargs["key_filename"] = resolved_key
                elif key_candidates:
                    connect_kwargs["key_filename"] = key_candidates[0]
                if self.password:
                    connect_kwargs["password"] = self.password

                connected = False
                conn_err = None
                for conn_try in range(3):
                    try:
                        ssh.connect(**connect_kwargs)
                        connected = True
                        break
                    except Exception as ce:
                        if _is_auth_exception(ce):
                            raise  # 认证类失败重试无意义，立即上抛精准诊断
                        conn_err = ce
                        self._log.warning(f"SSH 连接重试 ({conn_try + 1}/3) 失败: {ce}")
                        time.sleep(2)
                if not connected:
                    raise conn_err or RuntimeError("SSH 连接失败")

                self._log.info("SSH 连接成功建立，开启 TCP Keep-Alive")
                transport = ssh.get_transport()
                if transport is not None:
                    transport.set_keepalive(15)

                logs: List[str] = []
                for step in self.build_pipeline():
                    step_id = step["id"]
                    step_title = step["title"]
                    self._log.info(f"开始步骤 [{step_id}]: {step_title}")
                    # 关键调试信息：记录即将执行的完整远程命令
                    self._log.log_command(step_id, step["command"])
                    step_header = f"--- {step_title} ---"
                    logs.append(step_header)
                    if on_step:
                        on_step(step_id, step_title, step_header)

                    # Sending the command through stdin prevents the SSH login shell
                    # from expanding variables before Bash receives the script.
                    stdin, stdout, stderr = ssh.exec_command("bash -s")
                    stdin.write(step["command"] + "\n")
                    stdin.flush()
                    stdin.channel.shutdown_write()
                    channel = stdout.channel
                    step_output: List[str] = []
                    deadline = time.monotonic() + self.command_timeout
                    while not channel.exit_status_ready():
                        if channel.recv_ready():
                            chunk = channel.recv(4096).decode("utf-8", errors="replace")
                            step_output.append(chunk)
                            if on_step:
                                on_step(step_id, step_title, chunk)
                        if channel.recv_stderr_ready():
                            chunk = channel.recv_stderr(4096).decode("utf-8", errors="replace")
                            step_output.append(chunk)
                            if on_step:
                                on_step(step_id, step_title, chunk)
                        if time.monotonic() >= deadline:
                            channel.close()
                            msg = f"{step_title} 超过 {self.command_timeout // 60} 分钟仍未完成。"
                            self._log.error(f"步骤 [{step_id}] 执行超时: {msg}")
                            raise TimeoutError(msg)
                        time.sleep(0.2)

                    while channel.recv_ready():
                        step_output.append(channel.recv(4096).decode("utf-8", errors="replace"))
                    while channel.recv_stderr_ready():
                        step_output.append(channel.recv_stderr(4096).decode("utf-8", errors="replace"))

                    exit_status = channel.recv_exit_status()
                    step_log = "".join(step_output).strip()
                    if step_log:
                        logs.append(step_log)
                    # 输出结果解码（\uXXXX → 中文），日志直接可读
                    self._log.log_result(step_id, exit_status, step_log)
                    if exit_status != 0:
                        err_msg = f"{step_title} 失败（退出码 {exit_status}）：{step_log or '远程命令未返回错误详情。'}"
                        self._log.error(f"步骤 [{step_id}] 异常退出: {err_msg}")
                        raise RemoteStepError(err_msg)
                    self._log.info(f"步骤 [{step_id}] 执行成功")
                    if on_step:
                        on_step(step_id, step_title, f"{step_title} 已完成。")

                pipeline = self.build_pipeline()
                log_payload = {
                    "attempt": attempt,
                    "pipeline": pipeline,
                    "stdout": "\n".join(logs),
                    "stderr": "",
                }

                all_logs = "\n".join(logs)
                collection = self.extract_collection_payload(all_logs)
                dataset = DatasetDiscovery.extract_payload(all_logs)
                model = ModelDiscovery.extract_payload(all_logs)
                return {
                    "status": "success",
                    "message": "远程复现流水线已完成，日志已返回。",
                    "logs": json.dumps(log_payload, ensure_ascii=False, indent=2),
                    "metrics": collection.get("metrics", {}),
                    "dataset": dataset,
                    "model": model,
                    "metric_sources": collection.get("metric_sources", []),
                    "artifacts": collection.get("artifacts", []),
                    "attempts": attempt,
                }
            except Exception as exc:  # pragma: no cover
                last_error = exc
                if isinstance(exc, RemoteStepError):
                    break
                if _is_auth_exception(exc):
                    break  # 认证失败重试无意义：直接结束并输出精准诊断
                if attempt > self.max_retries:
                    break
                time.sleep(attempt * 3)
            finally:
                if ssh:
                    try:
                        ssh.close()
                    except Exception:
                        pass

        if _is_auth_exception(last_error):
            auth_state = self.detect_ssh_auth_sources()
            message = (
                f"SSH 认证失败（{type(last_error).__name__}）：云服务器 {self.user}@{self.host}:{self.port} "
                "拒绝了当前身份凭据，重试无意义，已尽快终止。可能原因："
                "1) “SSH 私钥路径”不是有效私钥（应填真实私钥文件路径或直接粘贴 -----BEGIN 私钥全文）；"
                "2) 本机公钥未加入云服务器 ~/.ssh/authorized_keys；"
                "3) 端口并非实例实际开放的 SSH 端口（AutoDL 等平台通常为 4xxxx 而非 22）；"
                "4) 密码认证时密码不正确。"
            )
            resolved = auth_state.get("resolved_key") or "无有效私钥文件"
            agent_count = len(auth_state.get("agent_keys") or [])
            message += f" 本地认证源检查：resolved_key={resolved}；ssh-agent 密钥数={agent_count}。"
            pub_hint = ""
            if resolved and resolved != "无有效私钥文件":
                pub_path = str(Path(resolved).with_suffix(".pub"))
                if os.path.isfile(pub_path):
                    try:
                        pub_content = Path(pub_path).read_text(
                            encoding="utf-8", errors="replace"
                        ).strip()
                        pub_hint = (
                            f" 本机配套公钥文件：{pub_path}（前 40 字符：{pub_content[:40]}…）。"
                            "若该公钥尚未授权，请将其全文复制并添加到云服务器 ~/.ssh/authorized_keys"
                            "（或 AutoDL 控制台的密钥管理页面）。"
                        )
                    except OSError:
                        pass
                else:
                    pub_hint = (
                        f" 未找到配套公钥文件 {pub_path}，请确认私钥对应的公钥已加入云服务器"
                        " ~/.ssh/authorized_keys。"
                    )
            message += pub_hint or " 若实例支持密码登录（AutoDL 创建实例时可设置 root 密码），也可改用密码认证。"
            return {"status": "failed", "message": message, "attempts": self.max_retries + 1}

        return {
            "status": "failed",
            "message": f"远程执行失败：{last_error}",
            "attempts": self.max_retries + 1,
        }
def _resolve_key_file(key_value: Any) -> str:
    """将私钥引用解析为真实文件路径：PEM 全文写入本机密钥文件，或校验路径存在。"""
    if key_value is None:
        return ""
    value = str(key_value).strip()
    if not value:
        return ""
    if value.startswith("-----BEGIN") or "PRIVATE KEY" in value.upper():
        ssh_dir = Path.home() / ".ssh" / "auto_generated"
        ssh_dir.mkdir(parents=True, exist_ok=True)
        key_file = ssh_dir / f"paper_repro_{abs(hash(value))}.key"
        if not key_file.exists() or key_file.read_text(encoding="utf-8", errors="replace") != value:
            key_file.write_text(value, encoding="utf-8")
            try:
                os.chmod(key_file, 0o600)
            except OSError:
                pass
        return str(key_file)
    expanded = os.path.expanduser(value)
    if expanded and os.path.isfile(expanded):
        return expanded
    return ""


def inject_public_key(
    host: str,
    user: str,
    port: str,
    key: str,
    password: str = "",
    public_key: str = "",
    timeout: int = 30,
) -> tuple[bool, str]:
    """将公钥一键注入云服务器 ~/.ssh/authorized_keys（幂等，等价于 ssh-copy-id）。

    使用密码（或已有私钥）临时登录一次，把公钥追加到服务器 authorized_keys，
    之后即可全程使用公钥认证登录——解决“AutoDL 控制台无密钥绑定入口”的问题。
    公钥以 base64 传输，避免引号/特殊字符在远端 shell 中展开出错。
    """
    host_value = (host or "").strip()
    user_value = (user or "").strip()
    port_value = (port or "22").strip()
    key_value = _resolve_key_file(key)
    pub_value = (public_key or "").strip()
    if not host_value or not user_value:
        return False, "请先填写云服务器地址和用户名。"
    if not pub_value:
        return False, "本机公钥为空，无法注入。请先确认已生成 SSH 密钥对。"
    if not password and not key_value:
        return False, "注入公钥需要登录凭据：请填写云服务器密码，或确认已填写的私钥路径有效。"
    if paramiko is None:
        return False, "无法执行公钥注入：缺少 paramiko 依赖。"

    b64_pub = base64.b64encode(pub_value.encode("utf-8")).decode("ascii")
    remote_cmd = (
        "mkdir -p ~/.ssh && chmod 700 ~/.ssh && touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys && "
        f"LINE=$(echo '{b64_pub}' | base64 -d) && "
        "(grep -qF \"$LINE\" ~/.ssh/authorized_keys || echo \"$LINE\" >> ~/.ssh/authorized_keys) && "
        "echo PUBKEY_INJECTED"
    )
    ssh = None
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            hostname=host_value,
            username=user_value,
            port=int(port_value) if port_value.isdigit() else 22,
            password=password or None,
            key_filename=key_value or None,
            timeout=timeout,
            allow_agent=True,
            look_for_keys=True,
        )
        _stdin, stdout, stderr = ssh.exec_command(remote_cmd, timeout=timeout)
        out = (stdout.read().decode("utf-8", errors="replace") or "").strip()
        err = (stderr.read().decode("utf-8", errors="replace") or "").strip()
        code = stdout.channel.recv_exit_status()
        if code == 0 and "PUBKEY_INJECTED" in out:
            return True, (
                f"✅ 公钥已成功注入 {user_value}@{host_value}：~/.ssh/authorized_keys "
                "（不存在时已自动追加）。现在提交任务直接使用自动生成的私钥即可，密码可留空。"
            )
        return False, f"公钥注入命令执行失败（退出码 {code}）：{err or out or '无输出'}"
    except Exception as exc:
        if _is_auth_exception(exc):
            return False, (
                f"SSH 认证失败：{user_value}@{host_value}:{port_value} 拒绝了当前凭据。"
                "请确认密码与实例 root 密码一致，或使用已获授权的私钥。"
            )
        return False, f"公钥注入失败：{exc}"
    finally:
        if ssh:
            try:
                ssh.close()
            except Exception:
                pass
